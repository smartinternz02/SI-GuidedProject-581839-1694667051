from flask import Flask, render_template,request
app = Flask(__name__)

import pickle
import numpy as np

model = pickle.load(open('diabetes_prediction.pkl','rb'))

@app.route('/')
def start():
  return render_template('index.html')

@app.route('/login',methods=['POST'])

def login():
  a = request.form["bp"]
  b = request.form["chl"]
  c = request.form["chlck"]
  d = request.form["bmi"]
  e = request.form["smo"]
  f = request.form["str"]
  g = request.form["hda"]
  h = request.form["pa"]
  i = request.form["fru"]
  j = request.form["veg"]
  k = request.form["hac"]
  l = request.form["ahc"]
  m = request.form["cbc"]
  n = request.form["gh"]
  o = request.form["mh"]
  p = request.form["ph"]
  q = request.form["wak"]
  r = request.form["sex"]
  s = request.form["age"]

  t = [[float(a),float(b),float(c),float(d),float(e),float(f),float(g),float(h),float(i),float(j),float(k),float(l),float(m),float(n),float(o),float(p),float(q),float(r),float(s)]]
  output = model.predict(t)
  print(output)
  return render_template("index.html", y = output)
  #if(output==0):
   # return render_template("index.html", y = "No Diabetes")
  #elif(output==1):
  #  return render_template("index.html", y = "Chances of getting Diabetes..")
  #elif(output==2):
   # return render_template("index.html", y = "Got affected by Diabetes")
  
if __name__ == '__main__':
  app.run(debug=True)